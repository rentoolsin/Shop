import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { PageHeader } from "../components/layout/PageHeader";
import { useDocumentMeta } from "../hooks/useDocumentMeta";

const LINKS = [
  { to: "/about", label: "About RenTools" },
  { to: "/contact", label: "Contact" },
  { to: "/location", label: "Location" },
];

export function More() {
  useDocumentMeta({ title: "More", description: "About, contact, and location information for RenTools." });

  return (
    <div>
      <PageHeader title="More" />
      <ul className="divide-y divide-graphite-200 dark:divide-graphite-800">
        {LINKS.map((link) => (
          <li key={link.to}>
            <Link
              to={link.to}
              className="flex items-center justify-between px-4 py-4 font-body text-[15px] text-ink transition-colors active:bg-graphite-100 dark:text-ink-inverted dark:active:bg-graphite-800"
            >
              {link.label}
              <ChevronRight className="h-4 w-4 text-graphite-400" strokeWidth={1.6} />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
